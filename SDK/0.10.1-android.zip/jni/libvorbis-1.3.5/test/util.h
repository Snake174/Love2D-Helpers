/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE OggVorbis SOFTWARE CODEC SOURCE CODE.   *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS LIBRARY SOURCE IS     *
 * GOVERNED BY A BSD-STYLE SOURCE LICENSE INCLUDED WITH THIS SOURCE *
 * IN 'COPYING'. PLEASE READ THESE TERMS BEFORE DISTRIBUTING.       *
 *                                                                  *
 * THE OggVorbis SOURCE CODE IS (C) COPYRIGHT 1994-2007             *
 * by the Xiph.Org Foundation http://www.xiph.org/                  *
 *                                                                  *
 ********************************************************************

 function: utility functions for vorbis codec test suite.
 last mod: $Id: util.h 19015 2013-11-12 04:13:28Z giles $

 ********************************************************************/

#define ARRAY_LEN(x)   (sizeof(x)/sizeof(x[0]))

/* Create simple test data consisting of a windowed sine wave. */
void gen_windowed_sine (float *data, int len, float maximum) ;

/* Set len values of data array to given value. */
void set_data_in (float * data, unsigned len, float value) ;
