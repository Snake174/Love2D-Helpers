/*
 * This source code is public domain.
 *
 * Authors: Olivier Lapicque <olivierl@jps.net>
*/


///////////////////////////////////////////////////
//
// J2B module loader
//
///////////////////////////////////////////////////
#include "stdafx.h"
#include "sndfile.h"

